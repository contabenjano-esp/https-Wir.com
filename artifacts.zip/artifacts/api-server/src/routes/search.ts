import { Router, type IRouter } from "express";

type SearchResult = {
  title: string;
  url: string;
  snippet: string;
};

const router: IRouter = Router();
const SEARCH_ENDPOINT = "https://html.duckduckgo.com/html/";
const MAX_QUERY_LENGTH = 120;

function decodeEntities(value: string): string {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#(\d+);/g, (_match, code: string) =>
      String.fromCharCode(Number(code)),
    )
    .replace(/&#x([0-9a-f]+);/gi, (_match, code: string) =>
      String.fromCharCode(parseInt(code, 16)),
    );
}

function cleanText(value: string): string {
  return decodeEntities(value.replace(/<[^>]*>/g, ""))
    .replace(/\s+/g, " ")
    .trim();
}

function getResultUrl(rawUrl: string): string | null {
  const decodedUrl = decodeEntities(rawUrl);
  const url = new URL(decodedUrl, "https://duckduckgo.com");
  const redirectedUrl = url.searchParams.get("uddg");
  const destination = redirectedUrl || url.toString();

  if (!/^https?:\/\//i.test(destination)) {
    return null;
  }

  return destination;
}

function parseResults(html: string): SearchResult[] {
  const titlePattern =
    /<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  const results: SearchResult[] = [];
  let titleMatch: RegExpExecArray | null;

  while ((titleMatch = titlePattern.exec(html)) !== null && results.length < 12) {
    const nextTitleIndex = html.search(
      /<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="/gi,
    );
    const resultSection = html.slice(
      titleMatch.index,
      nextTitleIndex > titleMatch.index ? nextTitleIndex : titleMatch.index + 5000,
    );
    const snippetMatch = resultSection.match(
      /class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/a>|class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/div>/i,
    );
    const url = getResultUrl(titleMatch[1]);

    if (!url) {
      continue;
    }

    results.push({
      title: cleanText(titleMatch[2]) || url,
      url,
      snippet: cleanText(snippetMatch?.[1] || snippetMatch?.[2] || ""),
    });
  }

  return results;
}

router.get("/search", async (req, res): Promise<void> => {
  const rawQuery = req.query.q;
  const query = Array.isArray(rawQuery) ? rawQuery[0] : rawQuery;

  if (typeof query !== "string" || query.trim().length === 0) {
    res.status(400).json({ error: "WHS necesita una búsqueda." });
    return;
  }

  const normalizedQuery = query.trim().slice(0, MAX_QUERY_LENGTH);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const upstreamUrl = new URL(SEARCH_ENDPOINT);
    upstreamUrl.searchParams.set("q", normalizedQuery);

    const response = await fetch(upstreamUrl, {
      headers: {
        "user-agent": "WHS/1.0 (+web search)",
        accept: "text/html",
      },
      signal: controller.signal,
    });

    if (!response.ok) {
      req.log.warn({ statusCode: response.status }, "WHS search source returned an error");
      res.status(502).json({ error: "La fuente de resultados de WHS no respondió." });
      return;
    }

    const html = await response.text();
    res.json({
      query: normalizedQuery,
      provider: "WHS",
      results: parseResults(html),
    });
  } catch (error) {
    req.log.warn({ err: error }, "WHS search request failed");
    res.status(502).json({ error: "WHS no pudo consultar resultados ahora." });
  } finally {
    clearTimeout(timeout);
  }
});

export default router;