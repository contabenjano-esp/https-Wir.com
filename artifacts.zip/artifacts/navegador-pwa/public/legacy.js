(function () {
  'use strict';

  var addressInput = document.getElementById('address-input');
  var connectForm = document.getElementById('connect-form');
  var renderSurface = document.getElementById('render-surface');
  var pageNotice = document.getElementById('page-notice');
  var connectionState = document.getElementById('connection-state');
  var installButton = document.getElementById('install-button');
  var installCopy = document.getElementById('install-copy');
  var promptEvent = null;
  var demoUrl = 'https://inicio';
  var domainPattern = /^(www\.)?[^/\s]+\.[^/\s]+$/i;

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function demoPage() {
    return '<div class="demo-content">' +
      '<p class="whs-label">WHS / WIRSLVE.E</p>' +
      '<h1>Tu búsqueda empieza aquí.</h1>' +
      '<div class="demo-line"></div>' +
      '<p>Escribe una frase en la barra superior para consultar WHS. Escribe un dominio como <strong>youtube.com</strong> para abrirlo directamente en el navegador.</p>' +
      '</div>';
  }

  function externalPage(destination) {
    return '<div class="launch-content">' +
      '<p class="whs-label">WHS / WIRSLVE.E</p>' +
      '<h1>Página lista para abrir.</h1>' +
      '<div class="demo-line"></div>' +
      '<p>Los sitios externos se abren en una pestaña real del navegador para conservar sus scripts, videos, sesiones y controles.</p>' +
      '<p class="destination">' + escapeHtml(destination) + '</p>' +
      '</div>';
  }

  function normalizeUrl(value) {
    var cleanValue = value.replace(/^\s+|\s+$/g, '');
    if (cleanValue === '' || cleanValue === demoUrl) {
      return demoUrl;
    }
    if (!/^https?:\/\//i.test(cleanValue) && domainPattern.test(cleanValue)) {
      return 'https://' + cleanValue;
    }
    return cleanValue;
  }

  function renderSearchResults(query, data) {
    var results = Array.isArray(data.results) ? data.results : [];
    var html = '<div class="whs-results">' +
      '<p class="whs-label">WHS / RESULTADOS</p>' +
      '<h1>Resultados para <strong>' + escapeHtml(query) + '</strong></h1>';

    if (results.length === 0) {
      html += '<div class="whs-empty"><strong>WHS no encontró resultados.</strong><p>Prueba otra frase o escribe un dominio completo para abrirlo directamente.</p></div>';
    } else {
      html += '<p class="whs-count">' + results.length + ' resultados encontrados por WHS</p>';
      var resultIndex;
      for (resultIndex = 0; resultIndex < results.length; resultIndex += 1) {
        var result = results[resultIndex] || {};
        var resultUrl = /^https?:\/\//i.test(result.url || '') ? result.url : '#';
        html += '<article class="search-result">' +
          '<a class="search-result-title" href="' + escapeHtml(resultUrl) + '" target="_blank" rel="noopener">' + escapeHtml(result.title || resultUrl) + '</a>' +
          '<div class="search-result-url">' + escapeHtml(resultUrl) + '</div>' +
          '<p>' + escapeHtml(result.snippet || 'Sin descripción disponible.') + '</p>' +
          '</article>';
      }
    }

    html += '</div>';
    renderSurface.innerHTML = html;
  }

  function renderSearchError(message) {
    renderSurface.innerHTML = '<div class="whs-empty">' +
      '<p class="whs-label">WHS / AVISO</p>' +
      '<h1>No se pudieron cargar los resultados.</h1>' +
      '<p>' + escapeHtml(message) + '</p>' +
      '<p>Comprueba la conexión e inténtalo otra vez.</p>' +
      '</div>';
  }

  function searchWithWhs(query) {
    var xhr = new XMLHttpRequest();
    var cleanQuery = query.replace(/^\s+|\s+$/g, '');

    addressInput.value = cleanQuery;
    renderSurface.innerHTML = '<div class="whs-empty"><p class="whs-label">WHS / BUSCANDO</p><h1>Consultando resultados...</h1><p>WHS está preparando una lista independiente.</p></div>';
    pageNotice.style.display = 'block';
    pageNotice.innerHTML = 'Resultados propios de WHS. No se utiliza Google para esta búsqueda.';
    connectionState.innerHTML = 'Buscando';

    xhr.open('GET', '/api/search?q=' + encodeURIComponent(cleanQuery), true);
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) {
        return;
      }

      if (xhr.status >= 200 && xhr.status < 300) {
        var response;
        try {
          response = JSON.parse(xhr.responseText);
        } catch (error) {
          renderSearchError('WHS recibió una respuesta no válida.');
          connectionState.innerHTML = 'Error';
          return;
        }
        renderSearchResults(cleanQuery, response);
        connectionState.innerHTML = 'WHS listo';
      } else {
        var message = 'WHS no pudo consultar su fuente de resultados.';
        try {
          message = JSON.parse(xhr.responseText).error || message;
        } catch (error) {
          /* Keep the readable default message. */
        }
        renderSearchError(message);
        connectionState.innerHTML = 'Error';
      }
    };
    xhr.onerror = function () {
      renderSearchError('No se pudo conectar con el servidor de WHS.');
      connectionState.innerHTML = 'Sin conexión';
    };
    xhr.send();
  }

  function openPage(value) {
    var cleanValue = value.replace(/^\s+|\s+$/g, '');
    if (cleanValue !== '' && cleanValue !== demoUrl &&
        !/^https?:\/\//i.test(cleanValue) && !domainPattern.test(cleanValue)) {
      searchWithWhs(cleanValue);
      return;
    }

    var destination = normalizeUrl(cleanValue);
    addressInput.value = destination;

    if (destination === demoUrl) {
      renderSurface.innerHTML = demoPage();
      pageNotice.style.display = 'none';
      connectionState.innerHTML = 'Demo';
      return;
    }

    renderSurface.innerHTML = externalPage(destination);
    pageNotice.style.display = 'block';
    pageNotice.innerHTML = 'Abriendo en una pestaña real. WHS no incrusta páginas externas.';
    connectionState.innerHTML = 'Abriendo';

    var openedWindow = window.open(destination, '_blank');
    if (!openedWindow) {
      window.location.href = destination;
    }
  }

  function installApplication() {
    if (promptEvent) {
      promptEvent.prompt();
      promptEvent.userChoice.then(function () {
        promptEvent = null;
        installButton.innerHTML = 'Instalada';
        installButton.disabled = true;
      });
      return;
    }
    installCopy.innerHTML = 'En IE11 guarda esta página como acceso directo. En Chrome y Edge usa el botón de instalación del navegador.';
  }

  connectForm.onsubmit = function (event) {
    event.preventDefault();
    openPage(addressInput.value);
  };

  document.getElementById('open-outside').onclick = function () {
    openPage(addressInput.value);
  };
  document.getElementById('reload-button').onclick = function () {
    window.location.reload();
  };
  document.getElementById('back-button').onclick = function () {
    window.history.back();
  };
  document.getElementById('forward-button').onclick = function () {
    window.history.forward();
  };

  var quickLinks = document.querySelectorAll('.quick-link');
  var quickIndex;
  for (quickIndex = 0; quickIndex < quickLinks.length; quickIndex += 1) {
    quickLinks[quickIndex].onclick = function () {
      openPage(this.getAttribute('data-url'));
    };
  }

  installButton.onclick = installApplication;

  window.addEventListener('beforeinstallprompt', function (event) {
    event.preventDefault();
    promptEvent = event;
    installCopy.innerHTML = 'Instala WIRSLVE.E como una aplicación independiente desde este navegador.';
  });

  window.addEventListener('appinstalled', function () {
    installButton.innerHTML = 'Instalada';
    installButton.disabled = true;
    installCopy.innerHTML = 'WIRSLVE.E está instalado en este dispositivo.';
  });

  openPage(demoUrl);
}());