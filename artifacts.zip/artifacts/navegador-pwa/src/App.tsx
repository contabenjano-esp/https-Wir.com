import { type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bookmark,
  Check,
  Compass,
  Globe2,
  History,
  Info,
  Menu,
  MoreHorizontal,
  Palette,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  Sparkles,
  Star,
  TimerReset,
  X,
  Zap,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
};

type Shortcut = {
  title: string;
  url: string;
  domain: string;
  tint: string;
  mark: string;
};

const shortcuts: Shortcut[] = [
  { title: 'Mastodon', url: 'https://mastodon.social', domain: 'mastodon.social', tint: '#e6d9c1', mark: 'm' },
  { title: 'Are.na', url: 'https://www.are.na', domain: 'are.na', tint: '#c7dfdb', mark: 'a' },
  { title: 'Figma', url: 'https://www.figma.com', domain: 'figma.com', tint: '#f3c2a9', mark: 'f' },
  { title: 'Readwise', url: 'https://readwise.io', domain: 'readwise.io', tint: '#d8d0eb', mark: 'r' },
];

const topics = [
  { label: 'Diseño', query: 'diseño de producto' },
  { label: 'Ideas', query: 'ideas para aprender' },
  { label: 'Noticias', query: 'noticias de hoy' },
  { label: 'Viajes', query: 'guías de viaje' },
];

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Buenos días';
  if (hour < 19) return 'Buenas tardes';
  return 'Buenas noches';
}

function SearchBar({
  initialValue = '',
  compact = false,
  onSubmit,
}: {
  initialValue?: string;
  compact?: boolean;
  onSubmit: (value: string) => void;
}) {
  const [value, setValue] = useState(initialValue);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (value.trim()) onSubmit(value.trim());
  };

  return (
    <form
      onSubmit={submit}
      className={`group relative flex items-center rounded-[1.35rem] border border-[#c9c4ba] bg-[#f9f7f1] transition-all duration-300 focus-within:border-[#ea7144] focus-within:ring-4 focus-within:ring-[#ea7144]/10 ${compact ? 'h-11' : 'h-[4.4rem] shadow-[0_15px_32px_rgba(46,49,62,0.09)]'}`}
    >
      <Search
        aria-hidden="true"
        className={`ml-5 shrink-0 text-[#ea7144] ${compact ? 'size-[17px]' : 'size-[21px]'}`}
        strokeWidth={2.1}
      />
      <label className="sr-only" htmlFor={compact ? 'browser-search-compact' : 'browser-search'}>
        Buscar o escribir una dirección
      </label>
      <input
        id={compact ? 'browser-search-compact' : 'browser-search'}
        data-testid={compact ? 'input-browser-search-compact' : 'input-browser-search'}
        type="search"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        placeholder={compact ? 'Buscar o escribir dirección' : 'Busca una idea, un sitio o escribe una dirección'}
        className={`min-w-0 flex-1 bg-transparent px-3 text-[#2e313e] outline-none placeholder:text-[#777978] ${compact ? 'text-sm' : 'text-[0.98rem]'}`}
        autoComplete="off"
      />
      {!compact && (
        <kbd className="mr-3 hidden rounded-lg border border-[#dad6cf] bg-[#efece4] px-2 py-1 font-mono text-[0.68rem] text-[#76756f] sm:block">
          Ctrl K
        </kbd>
      )}
      <button
        type="submit"
        data-testid={compact ? 'button-submit-search-compact' : 'button-submit-search'}
        aria-label="Enviar búsqueda"
        className={`mr-2 flex shrink-0 items-center justify-center rounded-xl bg-[#2e313e] text-[#f8f5ed] transition duration-200 hover:-translate-y-0.5 hover:bg-[#ea7144] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ea7144] focus-visible:ring-offset-2 ${compact ? 'size-8' : 'size-12'}`}
      >
        <ArrowUpRight className={compact ? 'size-4' : 'size-[19px]'} strokeWidth={2.1} />
      </button>
    </form>
  );
}

function BrandMark({ small = false }: { small?: boolean }) {
  return (
    <div className={`relative flex shrink-0 items-center justify-center bg-[#ea7144] text-[#2e313e] ${small ? 'size-8 rounded-[10px]' : 'size-10 rounded-[13px]'}`}>
      <Compass className={small ? 'size-[17px]' : 'size-[21px]'} strokeWidth={2.1} />
      <span className="absolute right-[5px] top-[5px] size-1.5 rounded-full bg-[#b9d9d3]" />
    </div>
  );
}

function BrowserToolbar({ onSearch }: { onSearch: (value: string) => void }) {
  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-[#d8d3c9] bg-[#e7e4db] px-3 py-2.5 sm:px-5">
      <div className="flex items-center gap-1">
        <button data-testid="button-browser-back" aria-label="Volver" className="chrome-control" onClick={() => window.history.back()}>
          <ArrowLeft className="size-[17px]" />
        </button>
        <button data-testid="button-browser-forward" aria-label="Avanzar" className="chrome-control" onClick={() => window.history.forward()}>
          <ArrowRight className="size-[17px]" />
        </button>
        <button data-testid="button-browser-reload" aria-label="Recargar" className="chrome-control" onClick={() => window.location.reload()}>
          <RefreshCw className="size-[16px]" />
        </button>
      </div>
      <div className="min-w-[220px] flex-1">
        <SearchBar compact onSubmit={onSearch} />
      </div>
      <div className="hidden items-center gap-1 sm:flex">
        <button data-testid="button-browser-bookmark" aria-label="Guardar página" className="chrome-control">
          <Bookmark className="size-[16px]" />
        </button>
        <button data-testid="button-browser-menu" aria-label="Más opciones" className="chrome-control">
          <MoreHorizontal className="size-[18px]" />
        </button>
      </div>
    </div>
  );
}

function ShortcutCard({ shortcut }: { shortcut: Shortcut }) {
  return (
    <a
      href={shortcut.url}
      target="_blank"
      rel="noreferrer"
      data-testid={`link-shortcut-${shortcut.title.toLowerCase()}`}
      className="group flex min-h-[128px] flex-col justify-between rounded-2xl border border-[#d4d0c7] bg-[#f9f7f1] p-4 transition-all duration-300 hover:-translate-y-1 hover:border-[#ea7144] hover:shadow-[0_15px_25px_rgba(46,49,62,0.08)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ea7144] focus-visible:ring-offset-2"
    >
      <div className="flex items-start justify-between">
        <span className="flex size-9 items-center justify-center rounded-xl text-lg font-bold lowercase text-[#2e313e]" style={{ backgroundColor: shortcut.tint }}>
          {shortcut.mark}
        </span>
        <ArrowUpRight className="size-4 text-[#a5a39c] transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-[#ea7144]" />
      </div>
      <div>
        <p className="text-sm font-bold tracking-[-0.02em] text-[#2e313e]">{shortcut.title}</p>
        <p className="mt-1 font-mono text-[0.63rem] text-[#8c8981]">{shortcut.domain}</p>
      </div>
    </a>
  );
}

function InstallPanel({
  canInstall,
  onInstall,
  onDismiss,
  dismissed = false,
}: {
  canInstall: boolean;
  onInstall: () => void;
  onDismiss?: () => void;
  dismissed?: boolean;
}) {
  if (dismissed) return null;
  return (
    <section className="relative overflow-hidden rounded-[1.6rem] border border-[#e66b40]/35 bg-[#ea7144] p-5 text-[#2e313e] shadow-[0_18px_38px_rgba(234,113,68,0.2)] sm:p-6">
      <div className="absolute -right-8 -top-12 size-36 rounded-full border-[18px] border-[#f8c1a4]/50" />
      <div className="absolute bottom-[-42px] right-20 size-24 rounded-full border-[13px] border-[#b9d9d3]/40" />
      <div className="relative flex items-start justify-between gap-5">
        <div>
          <div className="mb-3 flex size-10 items-center justify-center rounded-xl bg-[#2e313e] text-[#f8f5ed]">
            <Zap className="size-[19px]" fill="currentColor" />
          </div>
          <p className="font-mono text-[0.68rem] font-medium uppercase tracking-[0.14em] text-[#71361f]">Tu atajo favorito</p>
          <h2 className="mt-2 max-w-[19rem] font-display text-[1.65rem] font-bold leading-[0.98]">
            Navegador, pero a tu manera.
          </h2>
          <p className="mt-3 max-w-[26rem] text-sm leading-relaxed text-[#613624]">
            Instálalo para abrir este espacio en un toque, sin pestañas perdidas ni distracciones.
          </p>
        </div>
        {onDismiss && (
          <button
            data-testid="button-dismiss-install"
            aria-label="Cerrar invitación de instalación"
            onClick={onDismiss}
            className="relative rounded-full p-1.5 text-[#71361f] transition hover:bg-[#f8c1a4]/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2e313e]"
          >
            <X className="size-[18px]" />
          </button>
        )}
      </div>
      <div className="relative mt-5 flex flex-wrap items-center gap-3">
        {canInstall ? (
          <button
            data-testid="button-install-pwa"
            onClick={onInstall}
            className="inline-flex items-center gap-2 rounded-xl bg-[#2e313e] px-4 py-2.5 text-sm font-bold text-[#f8f5ed] transition hover:-translate-y-0.5 hover:bg-[#424654] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2e313e] focus-visible:ring-offset-2 focus-visible:ring-offset-[#ea7144]"
          >
            <Plus className="size-4" />
            Instalar Navegador
          </button>
        ) : (
          <div className="rounded-xl border border-[#71361f]/25 bg-[#f8c1a4]/40 px-3.5 py-2.5 text-xs leading-relaxed text-[#613624]">
            <span className="font-bold">Instalación rápida:</span> abre el menú de tu navegador y elige “Añadir a pantalla de inicio”.
          </div>
        )}
        <span className="font-mono text-[0.65rem] uppercase tracking-[0.11em] text-[#71361f]">
          {canInstall ? 'Un toque · Sin registro' : 'Funciona en cualquier navegador'}
        </span>
      </div>
    </section>
  );
}

function InstallToast({
  canInstall,
  onInstall,
  onDismiss,
}: {
  canInstall: boolean;
  onInstall: () => void;
  onDismiss: () => void;
}) {
  return (
    <div className="fixed inset-x-3 bottom-3 z-40 mx-auto max-w-3xl intro-reveal sm:inset-x-5 sm:bottom-5">
      <div className="chrome-shadow flex items-center gap-3 rounded-2xl border border-[#d2cec4] bg-[#f9f7f1]/95 p-3 backdrop-blur-md sm:gap-4 sm:px-4 sm:py-3.5">
        <div className="hidden size-9 shrink-0 items-center justify-center rounded-xl bg-[#ea7144] sm:flex">
          <Zap className="size-[17px] text-[#2e313e]" fill="currentColor" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold text-[#2e313e]">Llévate Navegador contigo</p>
          <p className="truncate text-xs text-[#777978]">{canInstall ? 'Abre tu start page en un toque.' : 'Añádelo desde el menú de tu navegador.'}</p>
        </div>
        {canInstall ? (
          <button data-testid="button-install-pwa-sticky" onClick={onInstall} className="shrink-0 rounded-xl bg-[#2e313e] px-3 py-2 text-xs font-bold text-[#f9f7f1] transition hover:bg-[#ea7144] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ea7144] sm:px-4">
            Instalar
          </button>
        ) : (
          <div className="hidden shrink-0 items-center gap-1.5 text-[0.68rem] font-semibold text-[#777978] sm:flex">
            <Info className="size-3.5" />
            Menú del navegador
          </div>
        )}
        <button data-testid="button-dismiss-install-sticky" aria-label="Ahora no" onClick={onDismiss} className="shrink-0 rounded-lg p-2 text-[#777978] transition hover:bg-[#efece4] hover:text-[#2e313e] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ea7144]">
          <X className="size-4" />
        </button>
      </div>
    </div>
  );
}

function Home() {
  const [deferredPrompt, setDeferredPrompt] = useState<InstallPromptEvent | null>(null);
  const [installDismissed, setInstallDismissed] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [activeTopic, setActiveTopic] = useState('Diseño');
  const [showAllShortcuts, setShowAllShortcuts] = useState(false);
  const [time, setTime] = useState(() => new Date());
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setDeferredPrompt(event as InstallPromptEvent);
    };
    const onAppInstalled = () => {
      setInstalled(true);
      setDeferredPrompt(null);
    };
    window.addEventListener('beforeinstallprompt', onBeforeInstallPrompt);
    window.addEventListener('appinstalled', onAppInstalled);
    const ticker = window.setInterval(() => setTime(new Date()), 60000);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstallPrompt);
      window.removeEventListener('appinstalled', onAppInstalled);
      window.clearInterval(ticker);
    };
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        searchRef.current?.querySelector('input')?.focus();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const greeting = useMemo(() => getGreeting(), [time]);
  const formattedTime = useMemo(
    () =>
      new Intl.DateTimeFormat('es-ES', {
        hour: '2-digit',
        minute: '2-digit',
      }).format(time),
    [time],
  );
  const formattedDate = useMemo(
    () =>
      new Intl.DateTimeFormat('es-ES', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
      }).format(time),
    [time],
  );
  const visibleShortcuts = showAllShortcuts ? shortcuts : shortcuts.slice(0, 3);

  const handleSearch = (rawValue: string) => {
    const value = rawValue.trim();
    const looksLikeUrl = /^https?:\/\//i.test(value) || (/^[\w-]+(\.[\w-]+)+/.test(value) && !value.includes(' '));
    const destination = looksLikeUrl
      ? (/^https?:\/\//i.test(value) ? value : `https://${value}`)
      : `https://www.google.com/search?q=${encodeURIComponent(value)}`;
    window.location.assign(destination);
  };

  const install = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === 'accepted') setInstalled(true);
    setDeferredPrompt(null);
  };

  const useTopic = (topic: { label: string; query: string }) => {
    setActiveTopic(topic.label);
    handleSearch(topic.query);
  };

  const canInstall = Boolean(deferredPrompt) && !installed;
  const inviteVisible = !installDismissed && !installed;

  return (
    <main className="app-noise min-h-[100dvh] text-[#2e313e]">
      <div className="mx-auto max-w-[1440px] px-3 py-3 sm:px-6 sm:py-6 lg:px-10">
        <header className="intro-reveal flex items-center justify-between gap-4 px-1 pb-4 sm:px-2">
          <div className="flex items-center gap-3">
            <BrandMark />
            <div>
              <p className="font-display text-[1.15rem] font-bold leading-none tracking-[-0.04em]">Navegador</p>
              <p className="mt-1 font-mono text-[0.58rem] uppercase tracking-[0.16em] text-[#777978]">Tu punto de partida</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button data-testid="button-open-history" aria-label="Abrir historial" className="header-icon-button">
              <History className="size-[17px]" />
            </button>
            <button data-testid="button-open-settings" aria-label="Abrir ajustes" className="header-icon-button">
              <Settings2 className="size-[17px]" />
            </button>
            <button data-testid="button-open-menu" aria-label="Abrir menú" className="header-icon-button sm:hidden">
              <Menu className="size-[17px]" />
            </button>
          </div>
        </header>

        <section className="chrome-shadow overflow-hidden rounded-[1.65rem] border border-[#cbc7bd] bg-[#f9f7f1]">
          <div className="flex items-center gap-2 border-b border-[#d8d3c9] bg-[#e7e4db] px-4 pt-3 sm:px-6">
            <div className="flex min-w-0 max-w-[17rem] items-center gap-2 rounded-t-xl border border-b-0 border-[#d2cec4] bg-[#f9f7f1] px-3 py-2.5 sm:max-w-xs">
              <BrandMark small />
              <span className="truncate text-xs font-bold text-[#2e313e]">Nueva pestaña</span>
              <X className="ml-auto size-3.5 shrink-0 text-[#a4a199]" />
            </div>
            <button data-testid="button-new-tab" aria-label="Nueva pestaña" className="mb-1 rounded-lg p-1.5 text-[#777978] transition hover:bg-[#d8d3c9] hover:text-[#2e313e]">
              <Plus className="size-4" />
            </button>
          </div>
          <BrowserToolbar onSearch={handleSearch} />

          <div className="topographic relative overflow-hidden px-5 pb-12 pt-12 sm:px-10 sm:pb-16 sm:pt-16 lg:px-20">
            <div className="pointer-events-none absolute -right-16 top-[-5rem] size-64 rounded-full border-[28px] border-[#b9d9d3]/60 sm:size-96 sm:border-[42px]" />
            <div className="pointer-events-none absolute -left-20 bottom-[-7rem] size-60 rounded-full border-[25px] border-[#f2c7ad]/55 sm:size-80" />
            <div className="relative mx-auto max-w-3xl">
              <div className="intro-reveal-delay-1 intro-reveal mb-8 flex items-end justify-between gap-5">
                <div>
                  <p className="mono-type text-[0.7rem] font-medium uppercase tracking-[0.15em] text-[#777978]">{formattedDate}</p>
                  <h1 data-testid="text-greeting" className="display-type mt-3 text-[clamp(2.5rem,7vw,5.4rem)] font-bold leading-[0.88] text-[#2e313e]">
                    {greeting},<br />
                    <span className="text-[#ea7144]">explorador.</span>
                  </h1>
                </div>
                <div className="float-slow hidden rounded-[1.25rem] border border-[#d2cec4] bg-[#f9f7f1]/80 px-4 py-3 text-right sm:block">
                  <p className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-[#929089]">Ahora</p>
                  <p className="mt-1 font-display text-2xl font-bold tracking-[-0.06em]">{formattedTime}</p>
                </div>
              </div>

              <div ref={searchRef} className="intro-reveal intro-reveal-delay-2">
                <SearchBar onSubmit={handleSearch} />
                <p className="mt-3 flex items-center gap-2 px-1 text-xs text-[#777978]">
                  <span className="pulse-dot size-1.5 rounded-full bg-[#ea7144]" />
                  Escribe una dirección o deja que la curiosidad decida.
                </p>
              </div>

              <div className="intro-reveal intro-reveal-delay-3 mt-8 flex flex-wrap gap-2">
                {topics.map((topic) => (
                  <button
                    key={topic.label}
                    data-testid={`button-topic-${topic.label.toLowerCase()}`}
                    onClick={() => useTopic(topic)}
                    className={`rounded-full border px-3.5 py-2 text-xs font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ea7144] focus-visible:ring-offset-2 ${activeTopic === topic.label ? 'border-[#2e313e] bg-[#2e313e] text-[#f9f7f1]' : 'border-[#cbc7bd] bg-[#f9f7f1]/75 text-[#777978] hover:border-[#ea7144] hover:text-[#2e313e]'}`}
                  >
                    {topic.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid gap-10 border-t border-[#d8d3c9] px-5 py-8 sm:px-10 lg:grid-cols-[1fr_0.72fr] lg:px-20 lg:py-10">
            <section>
              <div className="mb-5 flex items-end justify-between gap-3">
                <div>
                  <p className="font-mono text-[0.65rem] uppercase tracking-[0.15em] text-[#929089]">Tus lugares</p>
                  <h2 className="mt-1 font-display text-2xl font-bold tracking-[-0.045em]">Accesos rápidos</h2>
                </div>
                <button
                  data-testid="button-toggle-shortcuts"
                  onClick={() => setShowAllShortcuts((value) => !value)}
                  className="text-xs font-bold text-[#ea7144] underline decoration-[#f2c7ad] underline-offset-4 transition hover:text-[#b64e2d] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ea7144]"
                >
                  {showAllShortcuts ? 'Ver menos' : 'Ver todos'}
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {visibleShortcuts.map((shortcut) => (
                  <ShortcutCard key={shortcut.title} shortcut={shortcut} />
                ))}
                <button
                  data-testid="button-add-shortcut"
                  className="group flex min-h-[128px] flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-[#c9c4ba] bg-transparent text-[#929089] transition-all hover:border-[#ea7144] hover:bg-[#f2c7ad]/15 hover:text-[#ea7144] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ea7144]"
                  onClick={() => setShowAllShortcuts(true)}
                >
                  <span className="flex size-9 items-center justify-center rounded-xl border border-current transition-transform group-hover:rotate-90">
                    <Plus className="size-4" />
                  </span>
                  <span className="text-xs font-bold">Añadir sitio</span>
                </button>
              </div>
            </section>

            <section className="relative overflow-hidden rounded-[1.4rem] bg-[#2e313e] p-5 text-[#f9f7f1] sm:p-6">
              <div className="absolute -right-10 -top-10 size-40 rounded-full border-[19px] border-[#b9d9d3]/20" />
              <div className="relative flex h-full flex-col justify-between">
                <div>
                  <div className="mb-6 flex items-center justify-between">
                    <div className="flex size-9 items-center justify-center rounded-xl bg-[#b9d9d3] text-[#2e313e]">
                      <Sparkles className="size-[17px]" />
                    </div>
                    <span className="font-mono text-[0.6rem] uppercase tracking-[0.16em] text-[#aab6b1]">Pequeño ritual</span>
                  </div>
                  <h2 className="max-w-[13rem] font-display text-[1.8rem] font-bold leading-[0.98] tracking-[-0.055em]">
                    Un poco de internet, bien elegido.
                  </h2>
                  <p className="mt-4 max-w-[18rem] text-sm leading-relaxed text-[#c5c7c2]">
                    Un espacio liviano para empezar con intención. Nada de ruido, solo tu siguiente clic.
                  </p>
                </div>
                <button data-testid="button-discover" onClick={() => handleSearch('sitios interesantes para descubrir')} className="mt-8 flex w-full items-center justify-between rounded-xl border border-[#525661] px-3.5 py-3 text-left text-xs font-bold text-[#f9f7f1] transition hover:border-[#b9d9d3] hover:bg-[#424654] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#b9d9d3]">
                  <span>Descubrir algo nuevo</span>
                  <ArrowUpRight className="size-4 text-[#b9d9d3]" />
                </button>
              </div>
            </section>
          </div>
        </section>

        <section className="grid gap-4 px-1 py-6 sm:grid-cols-3 sm:px-2 sm:py-8">
          {[
            { icon: TimerReset, title: 'Abre y listo', copy: 'Tu punto de partida, sin pasos de más.' },
            { icon: Palette, title: 'Hecho para ti', copy: 'Un inicio con tus lugares y tu ritmo.' },
            { icon: Globe2, title: 'Internet abierto', copy: 'Busca cualquier cosa. Ve a cualquier parte.' },
          ].map(({ icon: Icon, title, copy }, index) => (
            <div key={title} className={`intro-reveal intro-reveal-delay-${index + 1} flex gap-3 rounded-2xl border border-[#d3cfc6] bg-[#f4f1e9]/60 p-4`}>
              <Icon className="mt-0.5 size-[18px] shrink-0 text-[#ea7144]" />
              <div>
                <p className="text-sm font-bold">{title}</p>
                <p className="mt-1 text-xs leading-relaxed text-[#777978]">{copy}</p>
              </div>
            </div>
          ))}
        </section>

        {inviteVisible && (
          <div className="mx-1 mb-24 mt-2 max-w-2xl sm:mx-2 sm:mb-10 sm:mt-3">
            <InstallPanel canInstall={canInstall} onInstall={install} onDismiss={() => setInstallDismissed(true)} />
          </div>
        )}

        <footer className="flex flex-col gap-3 px-2 pb-20 pt-2 text-[0.67rem] text-[#929089] sm:flex-row sm:items-center sm:justify-between sm:pb-4">
          <p className="font-mono uppercase tracking-[0.13em]">Navegador PWA / 01</p>
          <div className="flex items-center gap-4">
            <button data-testid="button-about" className="transition hover:text-[#2e313e]">Acerca de</button>
            <button data-testid="button-privacy" className="transition hover:text-[#2e313e]">Privacidad</button>
            <span className="flex items-center gap-1.5"><Star className="size-3 text-[#ea7144]" fill="currentColor" /> Hecho para explorar</span>
          </div>
        </footer>
      </div>
      {inviteVisible && <InstallToast canInstall={canInstall} onInstall={install} onDismiss={() => setInstallDismissed(true)} />}
    </main>
  );
}

function BrowserChromeStyles() {
  return (
    <style>{`
      .chrome-control { display: inline-flex; align-items: center; justify-content: center; width: 2.1rem; height: 2.1rem; border-radius: .7rem; color: #777978; transition: background-color .2s, color .2s, transform .2s; }
      .chrome-control:hover { background: #d8d3c9; color: #2e313e; transform: translateY(-1px); }
      .chrome-control:focus-visible { outline: 2px solid #ea7144; outline-offset: 2px; }
      .header-icon-button { display: inline-flex; align-items: center; justify-content: center; width: 2.25rem; height: 2.25rem; border: 1px solid #d2cec4; border-radius: .8rem; color: #777978; background: rgba(249,247,241,.55); transition: background-color .2s, color .2s, transform .2s; }
      .header-icon-button:hover { background: #f9f7f1; color: #2e313e; transform: translateY(-1px); }
      .header-icon-button:focus-visible { outline: 2px solid #ea7144; outline-offset: 2px; }
    `}</style>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <BrowserChromeStyles />
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;